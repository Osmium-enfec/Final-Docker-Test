from django.http import JsonResponse

def greet(request):
    # TODO: implement this function
    # Accept 'name' query parameter, default to 'World'
    # Return JSON: {'greeting': 'Hello, <name>!'}
    pass
